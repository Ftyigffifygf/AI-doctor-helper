// AIME Medical Application JavaScript

class AIMEApp {
    constructor() {
        this.currentModule = 'dashboard';
        this.sessionData = {};
        this.vitalsInterval = null;
        this.recordingTimer = null;
        this.recordingStartTime = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.startVitalsSimulation();
        this.loadSessionData();
        
        // Show disclaimer modal after short delay to ensure DOM is ready
        setTimeout(() => {
            this.showDisclaimerModal();
        }, 100);
    }

    setupEventListeners() {
        // Navigation - ensure event listeners are properly attached
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const module = e.currentTarget.getAttribute('data-module');
                console.log('Navigation clicked:', module);
                if (module) {
                    this.switchModule(module);
                }
            });
        });

        // Module cards in dashboard
        document.querySelectorAll('.module-card').forEach(card => {
            card.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const module = e.currentTarget.getAttribute('data-module');
                console.log('Module card clicked:', module);
                if (module) {
                    this.switchModule(module);
                }
            });
        });

        // Modal handling - fix the modal dismissal issue
        const closeDisclaimerBtn = document.getElementById('close-disclaimer');
        if (closeDisclaimerBtn) {
            closeDisclaimerBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('Close disclaimer clicked');
                this.hideDisclaimerModal();
            });
        }
        
        const acceptDisclaimerBtn = document.getElementById('accept-disclaimer');
        if (acceptDisclaimerBtn) {
            acceptDisclaimerBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('Accept disclaimer clicked');
                this.hideDisclaimerModal();
            });
        }

        // Close modal when clicking outside
        const disclaimerModal = document.getElementById('disclaimer-modal');
        if (disclaimerModal) {
            disclaimerModal.addEventListener('click', (e) => {
                if (e.target === disclaimerModal) {
                    this.hideDisclaimerModal();
                }
            });
        }

        // Diagnostic module
        const loadSampleBtn = document.getElementById('load-sample-symptoms');
        if (loadSampleBtn) {
            loadSampleBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.loadSampleSymptoms();
            });
        }
        
        const analyzeSymptomsBtn = document.getElementById('analyze-symptoms');
        if (analyzeSymptomsBtn) {
            analyzeSymptomsBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.analyzeSymptoms();
            });
        }

        // Scribe module
        const startRecBtn = document.getElementById('start-recording');
        if (startRecBtn) {
            startRecBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.startRecording();
            });
        }
        
        const stopRecBtn = document.getElementById('stop-recording');
        if (stopRecBtn) {
            stopRecBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.stopRecording();
            });
        }
        
        const uploadAudioBtn = document.getElementById('upload-audio');
        if (uploadAudioBtn) {
            uploadAudioBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const audioFile = document.getElementById('audio-file');
                if (audioFile) audioFile.click();
            });
        }
        
        const audioFileInput = document.getElementById('audio-file');
        if (audioFileInput) {
            audioFileInput.addEventListener('change', this.handleAudioUpload.bind(this));
        }

        // Scan module
        this.setupFileUpload('scan-upload-area', 'scan-file', this.handleScanUpload.bind(this));
        const analyzeScanBtn = document.getElementById('analyze-scan');
        if (analyzeScanBtn) {
            analyzeScanBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.analyzeScan();
            });
        }

        // Genomics module
        this.setupFileUpload('genomics-upload-area', 'genomics-file', this.handleGenomicsUpload.bind(this));
        const analyzeGenomicsBtn = document.getElementById('analyze-genomics');
        if (analyzeGenomicsBtn) {
            analyzeGenomicsBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.analyzeGenomics();
            });
        }

        // Lab module
        this.setupFileUpload('lab-upload-area', 'lab-file', this.handleLabUpload.bind(this));
        const analyzeLabBtn = document.getElementById('analyze-lab');
        if (analyzeLabBtn) {
            analyzeLabBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.analyzeLab();
            });
        }

        // Motion module
        const startWebcamBtn = document.getElementById('start-webcam');
        if (startWebcamBtn) {
            startWebcamBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.startWebcam();
            });
        }
        
        const stopWebcamBtn = document.getElementById('stop-webcam');
        if (stopWebcamBtn) {
            stopWebcamBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.stopWebcam();
            });
        }
        
        const uploadMotionBtn = document.getElementById('upload-motion-video');
        if (uploadMotionBtn) {
            uploadMotionBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const motionVideo = document.getElementById('motion-video');
                if (motionVideo) motionVideo.click();
            });
        }
        
        const motionVideoInput = document.getElementById('motion-video');
        if (motionVideoInput) {
            motionVideoInput.addEventListener('change', this.handleMotionUpload.bind(this));
        }
        
        const analyzeMotionBtn = document.getElementById('analyze-motion');
        if (analyzeMotionBtn) {
            analyzeMotionBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.analyzeMotion();
            });
        }

        // Vitals module
        const syncWearablesBtn = document.getElementById('sync-wearables');
        if (syncWearablesBtn) {
            syncWearablesBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.syncWearables();
            });
        }
        
        const generateVitalsReportBtn = document.getElementById('generate-vitals-report');
        if (generateVitalsReportBtn) {
            generateVitalsReportBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.generateVitalsReport();
            });
        }

        // Agent module
        const sendAgentBtn = document.getElementById('send-agent-message');
        if (sendAgentBtn) {
            sendAgentBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.sendAgentMessage();
            });
        }
        
        const agentInput = document.getElementById('agent-input');
        if (agentInput) {
            agentInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendAgentMessage();
                }
            });
        }
        
        document.querySelectorAll('.suggestion-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const query = e.currentTarget.dataset.query;
                const agentInput = document.getElementById('agent-input');
                if (agentInput && query) {
                    agentInput.value = query;
                    this.sendAgentMessage();
                }
            });
        });

        // Header actions
        const exportBtn = document.getElementById('export-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.exportReport();
            });
        }
        
        const newPatientBtn = document.getElementById('new-patient-btn');
        if (newPatientBtn) {
            newPatientBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.newPatient();
            });
        }

        // Add keyboard escape listener for modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const modal = document.getElementById('disclaimer-modal');
                if (modal && !modal.classList.contains('hidden')) {
                    this.hideDisclaimerModal();
                }
            }
        });
    }

    setupFileUpload(areaId, fileId, handler) {
        const area = document.getElementById(areaId);
        const fileInput = document.getElementById(fileId);
        
        if (!area || !fileInput) return;

        area.addEventListener('click', () => fileInput.click());
        area.addEventListener('dragover', (e) => {
            e.preventDefault();
            area.classList.add('dragover');
        });
        area.addEventListener('dragleave', () => {
            area.classList.remove('dragover');
        });
        area.addEventListener('drop', (e) => {
            e.preventDefault();
            area.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                handler({ target: { files } });
            }
        });
        fileInput.addEventListener('change', handler);
    }

    switchModule(moduleName) {
        console.log('Switching to module:', moduleName);
        
        // Update navigation active state
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        const navItem = document.querySelector(`[data-module="${moduleName}"]`);
        if (navItem) {
            navItem.classList.add('active');
            console.log('Added active class to nav item:', moduleName);
        } else {
            console.error('Nav item not found for module:', moduleName);
        }

        // Hide all modules
        document.querySelectorAll('.module').forEach(module => {
            module.classList.remove('active');
            module.style.display = 'none';
        });
        
        // Show target module
        const targetModule = document.getElementById(moduleName);
        if (targetModule) {
            targetModule.classList.add('active');
            targetModule.style.display = 'block';
            console.log('Activated module:', moduleName);
        } else {
            console.error('Target module not found:', moduleName);
        }

        // Update page title
        const titles = {
            dashboard: 'Dashboard',
            diagnostic: 'AI Diagnostic Assistant',
            scribe: 'AI Medical Scribe',
            scan: 'Scan Analyzer',
            genomics: 'Genomic Predictor',
            lab: 'Lab Report Parser',
            motion: 'Motion Analysis Tool',
            vitals: 'Vitals & Wearable Sync',
            agent: 'Doctor Agent Hub'
        };
        
        const pageTitle = document.getElementById('page-title');
        if (pageTitle) {
            pageTitle.textContent = titles[moduleName] || moduleName;
            console.log('Updated page title to:', titles[moduleName] || moduleName);
        }
        
        this.currentModule = moduleName;
    }

    // Diagnostic Module Functions
    loadSampleSymptoms() {
        const sampleText = "I have been experiencing chest pain, shortness of breath, and fatigue for the past week. The chest pain is sharp and occurs mainly when I exert myself. I also feel dizzy sometimes and have been sweating more than usual.";
        const symptomsInput = document.getElementById('symptoms-input');
        if (symptomsInput) {
            symptomsInput.value = sampleText;
        }
    }

    async analyzeSymptoms() {
        const symptomsInput = document.getElementById('symptoms-input');
        if (!symptomsInput) return;
        
        const symptoms = symptomsInput.value.trim();
        if (!symptoms) {
            alert('Please enter symptoms to analyze.');
            return;
        }

        this.showResults('diagnostic');
        this.showLoading('diagnostic-loading');

        // Simulate AI processing
        await this.delay(3000);

        const results = this.generateDiagnosticResults(symptoms);
        this.hideLoading('diagnostic-loading');
        this.displayDiagnosticResults(results);
        
        this.sessionData.diagnostic = results;
        this.saveSessionData();
    }

    generateDiagnosticResults(symptoms) {
        const conditions = [
            { condition: "Acute Coronary Syndrome", confidence: 0.78, icd10: "I20.0", description: "Chest pain with exertion suggests possible cardiac origin" },
            { condition: "Pulmonary Embolism", confidence: 0.65, icd10: "I26.9", description: "Shortness of breath and chest pain combination" },
            { condition: "Anxiety Disorder", confidence: 0.45, icd10: "F41.9", description: "Physical symptoms may be anxiety-related" },
            { condition: "Heart Failure", confidence: 0.42, icd10: "I50.9", description: "Fatigue and shortness of breath pattern" }
        ];

        const tests = [
            { test: "ECG", priority: "High", rationale: "Rule out cardiac arrhythmias and ischemia" },
            { test: "Troponin levels", priority: "High", rationale: "Detect myocardial injury" },
            { test: "Chest X-ray", priority: "Medium", rationale: "Evaluate lung fields and heart size" },
            { test: "D-dimer", priority: "Medium", rationale: "Screen for pulmonary embolism" },
            { test: "CBC with differential", priority: "Low", rationale: "Rule out anemia as cause of fatigue" }
        ];

        return {
            conditions,
            tests,
            urgency: "High - Immediate medical attention recommended",
            confidence: 0.82,
            timestamp: new Date().toISOString()
        };
    }

    displayDiagnosticResults(results) {
        const output = document.getElementById('diagnostic-output');
        if (!output) return;
        
        output.innerHTML = `
            <div class="results-header">
                <h3 class="results-title">Diagnostic Analysis Results</h3>
                <span class="confidence-score">Confidence: ${(results.confidence * 100).toFixed(0)}%</span>
            </div>
            
            <div class="results-grid">
                <div class="results-card">
                    <h4>🎯 Primary Conditions</h4>
                    <ul class="condition-list">
                        ${results.conditions.map(condition => `
                            <li class="condition-item">
                                <div>
                                    <div class="condition-name">${condition.condition}</div>
                                    <div class="condition-description" style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-top: 4px;">
                                        ${condition.description}
                                    </div>
                                    <div style="font-size: var(--font-size-xs); color: var(--color-text-secondary); margin-top: 2px;">
                                        ICD-10: ${condition.icd10}
                                    </div>
                                </div>
                                <span class="condition-confidence" style="color: ${condition.confidence > 0.7 ? 'var(--color-error)' : condition.confidence > 0.5 ? 'var(--color-warning)' : 'var(--color-info)'}">
                                    ${(condition.confidence * 100).toFixed(0)}%
                                </span>
                            </li>
                        `).join('')}
                    </ul>
                </div>
                
                <div class="results-card">
                    <h4>🧪 Recommended Tests</h4>
                    <ul class="test-list">
                        ${results.tests.map(test => `
                            <li class="test-item">
                                <div>
                                    <div class="test-name">${test.test}</div>
                                    <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-top: 4px;">
                                        ${test.rationale}
                                    </div>
                                </div>
                                <span class="status status--${test.priority.toLowerCase() === 'high' ? 'error' : test.priority.toLowerCase() === 'medium' ? 'warning' : 'info'}">
                                    ${test.priority}
                                </span>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            </div>
            
            <div class="results-card" style="margin-top: var(--space-20); background: var(--color-bg-4); border-left: 4px solid var(--color-error);">
                <h4 style="color: var(--color-error);">⚠️ Clinical Assessment</h4>
                <p style="margin: 0; font-weight: var(--font-weight-medium); color: var(--color-text);">
                    ${results.urgency}
                </p>
                <p style="margin: var(--space-8) 0 0 0; font-size: var(--font-size-sm); color: var(--color-text-secondary);">
                    Based on symptom analysis, immediate cardiac evaluation is recommended. Consider emergency department evaluation for chest pain workup.
                </p>
            </div>
        `;
        output.classList.remove('hidden');
    }

    // Scribe Module Functions
    startRecording() {
        const startBtn = document.getElementById('start-recording');
        const stopBtn = document.getElementById('stop-recording');
        const recordingStatus = document.getElementById('recording-status');
        
        if (startBtn) startBtn.classList.add('hidden');
        if (stopBtn) stopBtn.classList.remove('hidden');
        if (recordingStatus) recordingStatus.classList.remove('hidden');
        
        this.recordingStartTime = Date.now();
        this.recordingTimer = setInterval(() => {
            const elapsed = Math.floor((Date.now() - this.recordingStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60).toString().padStart(2, '0');
            const seconds = (elapsed % 60).toString().padStart(2, '0');
            const timer = document.querySelector('.recording-timer');
            if (timer) {
                timer.textContent = `${minutes}:${seconds}`;
            }
        }, 1000);
    }

    stopRecording() {
        const startBtn = document.getElementById('start-recording');
        const stopBtn = document.getElementById('stop-recording');
        const recordingStatus = document.getElementById('recording-status');
        
        if (startBtn) startBtn.classList.remove('hidden');
        if (stopBtn) stopBtn.classList.add('hidden');
        if (recordingStatus) recordingStatus.classList.add('hidden');
        
        if (this.recordingTimer) {
            clearInterval(this.recordingTimer);
            this.recordingTimer = null;
        }

        this.processAudioTranscription();
    }

    handleAudioUpload(event) {
        const files = event.target.files;
        if (files.length > 0) {
            this.processAudioTranscription();
        }
    }

    async processAudioTranscription() {
        this.showResults('scribe');
        this.showLoading('scribe-loading');

        // Simulate AI processing
        await this.delay(4000);

        const results = this.generateScribeResults();
        this.hideLoading('scribe-loading');
        this.displayScribeResults(results);
        
        this.sessionData.scribe = results;
        this.saveSessionData();
    }

    generateScribeResults() {
        return {
            soap: {
                subjective: "Patient is a 45-year-old male presenting with acute onset chest pain that began approximately 2 hours ago. Describes pain as 8/10 in severity, sharp in nature, radiating to the left arm. Associated with shortness of breath, diaphoresis, and nausea. Denies recent trauma or previous similar episodes. Has family history of coronary artery disease.",
                objective: "Vital signs: BP 160/95 mmHg, HR 110 bpm, RR 22/min, O2 sat 96% on room air, Temp 98.8°F. Patient appears anxious and diaphoretic. Heart: Regular rate, no murmurs. Lungs: Clear to auscultation bilaterally. No peripheral edema noted.",
                assessment: "Acute chest pain, concerning for acute coronary syndrome. Differential includes myocardial infarction, unstable angina, or pulmonary embolism. Patient meets criteria for immediate cardiac workup.",
                plan: "Immediate ECG obtained. Serial troponins ordered q6h x3. Chest X-ray ordered. Started on continuous cardiac monitoring. Aspirin 325mg given. Cardiology consultation requested. Patient NPO pending further evaluation."
            },
            medications: [
                { medication: "Aspirin 325mg", route: "PO", frequency: "STAT", indication: "Antiplatelet therapy for suspected ACS" },
                { medication: "Metoprolol 25mg", route: "PO", frequency: "BID", indication: "Rate control if no contraindications" },
                { medication: "Atorvastatin 40mg", route: "PO", frequency: "Daily", indication: "High-intensity statin therapy" }
            ],
            orders: [
                "ECG STAT and repeat in 30 minutes",
                "Troponin I now and q6h x3",
                "Basic metabolic panel",
                "Chest X-ray portable",
                "Continuous cardiac monitoring"
            ],
            followUp: "Cardiology consultation within 2 hours. Patient to remain NPO. Reassess after initial workup results.",
            confidence: 0.91,
            timestamp: new Date().toISOString()
        };
    }

    displayScribeResults(results) {
        const output = document.getElementById('scribe-output');
        if (!output) return;
        
        output.innerHTML = `
            <div class="results-header">
                <h3 class="results-title">Medical Transcription - SOAP Notes</h3>
                <span class="confidence-score">Accuracy: ${(results.confidence * 100).toFixed(0)}%</span>
            </div>
            
            <div class="soap-section">
                <h5>Subjective</h5>
                <div class="soap-content">${results.soap.subjective}</div>
            </div>
            
            <div class="soap-section">
                <h5>Objective</h5>
                <div class="soap-content">${results.soap.objective}</div>
            </div>
            
            <div class="soap-section">
                <h5>Assessment</h5>
                <div class="soap-content">${results.soap.assessment}</div>
            </div>
            
            <div class="soap-section">
                <h5>Plan</h5>
                <div class="soap-content">${results.soap.plan}</div>
            </div>
            
            <div class="results-grid" style="margin-top: var(--space-24);">
                <div class="results-card">
                    <h4>💊 Medications</h4>
                    <ul class="test-list">
                        ${results.medications.map(med => `
                            <li class="test-item">
                                <div>
                                    <div class="test-name">${med.medication}</div>
                                    <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">
                                        ${med.route} ${med.frequency} - ${med.indication}
                                    </div>
                                </div>
                            </li>
                        `).join('')}
                    </ul>
                </div>
                
                <div class="results-card">
                    <h4>📋 Orders</h4>
                    <ul class="test-list">
                        ${results.orders.map(order => `
                            <li class="test-item">
                                <div class="test-name">${order}</div>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            </div>
            
            <div class="results-card" style="margin-top: var(--space-20);">
                <h4>📅 Follow-up</h4>
                <p style="margin: 0; color: var(--color-text);">${results.followUp}</p>
            </div>
        `;
        output.classList.remove('hidden');
    }

    // Vitals Module Functions
    startVitalsSimulation() {
        if (this.vitalsInterval) return;
        
        this.vitalsInterval = setInterval(() => {
            this.updateVitals();
        }, 5000);
    }

    updateVitals() {
        // Simulate realistic vital sign variations
        const heartRate = 68 + Math.floor(Math.random() * 12); // 68-80 BPM
        const systolic = 115 + Math.floor(Math.random() * 20); // 115-135
        const diastolic = 75 + Math.floor(Math.random() * 15); // 75-90
        const temp = 98.2 + (Math.random() * 1.2); // 98.2-99.4°F
        const oxygenSat = 96 + Math.floor(Math.random() * 4); // 96-99%
        const steps = 8200 + Math.floor(Math.random() * 500); // 8200-8700
        const sleep = 6.8 + (Math.random() * 1.0); // 6.8-7.8 hours

        const heartRateEl = document.getElementById('heart-rate');
        const bloodPressureEl = document.getElementById('blood-pressure');
        const temperatureEl = document.getElementById('temperature');
        const oxygenSatEl = document.getElementById('oxygen-sat');
        const stepsEl = document.getElementById('steps');
        const sleepEl = document.getElementById('sleep');

        if (heartRateEl) heartRateEl.textContent = heartRate;
        if (bloodPressureEl) bloodPressureEl.textContent = `${systolic}/${diastolic}`;
        if (temperatureEl) temperatureEl.textContent = temp.toFixed(1);
        if (oxygenSatEl) oxygenSatEl.textContent = oxygenSat;
        if (stepsEl) stepsEl.textContent = steps.toLocaleString();
        if (sleepEl) sleepEl.textContent = sleep.toFixed(1);
    }

    async syncWearables() {
        const button = document.getElementById('sync-wearables');
        if (!button) return;
        
        const originalText = button.textContent;
        button.textContent = '🔄 Syncing...';
        button.disabled = true;

        await this.delay(2000);

        button.textContent = '✅ Synced';
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
        }, 2000);

        // Update vitals with fresh data
        this.updateVitals();
    }

    async generateVitalsReport() {
        const button = document.getElementById('generate-vitals-report');
        if (!button) return;
        
        const originalText = button.textContent;
        button.textContent = '📊 Generating...';
        button.disabled = true;

        await this.delay(2000);

        const report = this.createVitalsReport();
        this.downloadReport('vitals-report.txt', report);

        button.textContent = '✅ Generated';
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
        }, 2000);
    }

    createVitalsReport() {
        const timestamp = new Date().toLocaleString();
        const heartRate = document.getElementById('heart-rate')?.textContent || '72';
        const bloodPressure = document.getElementById('blood-pressure')?.textContent || '120/80';
        const temperature = document.getElementById('temperature')?.textContent || '98.6';
        const oxygenSat = document.getElementById('oxygen-sat')?.textContent || '98';
        const steps = document.getElementById('steps')?.textContent || '8,450';
        const sleep = document.getElementById('sleep')?.textContent || '7.2';
        
        return `
VITALS MONITORING REPORT
Generated: ${timestamp}
Patient: John Doe (MRN: 12345)

CURRENT VITALS:
- Heart Rate: ${heartRate} BPM
- Blood Pressure: ${bloodPressure} mmHg
- Temperature: ${temperature}°F
- Oxygen Saturation: ${oxygenSat}%

ACTIVITY DATA:
- Steps Today: ${steps}
- Sleep Duration: ${sleep} hours

TRENDS:
- Heart rate variability: Normal
- Blood pressure: Stable within normal limits
- Activity level: Active (>8000 steps/day)
- Sleep quality: Good

ALERTS: None

RECOMMENDATIONS:
- Continue current activity level
- Monitor blood pressure regularly
- Maintain consistent sleep schedule
        `.trim();
    }

    // Agent Module Functions
    async sendAgentMessage() {
        const input = document.getElementById('agent-input');
        if (!input) return;
        
        const message = input.value.trim();
        if (!message) return;

        this.addChatMessage(message, 'user');
        input.value = '';

        // Show typing indicator
        const typingId = this.addChatMessage('AI is thinking...', 'agent', true);

        await this.delay(2000);

        const response = this.generateAgentResponse(message);
        this.removeChatMessage(typingId);
        this.addChatMessage(response, 'agent');
    }

    addChatMessage(message, sender, isTyping = false) {
        const messagesContainer = document.getElementById('chat-messages');
        if (!messagesContainer) return null;
        
        const messageId = `msg-${Date.now()}`;
        
        const messageElement = document.createElement('div');
        messageElement.className = `${sender}-message`;
        messageElement.id = messageId;
        
        messageElement.innerHTML = `
            <div class="message-avatar">${sender === 'user' ? '👤' : '🤖'}</div>
            <div class="message-content">
                <p>${message}</p>
                ${isTyping ? '<div class="typing-dots">...</div>' : ''}
            </div>
        `;
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        return messageId;
    }

    removeChatMessage(messageId) {
        if (!messageId) return;
        const element = document.getElementById(messageId);
        if (element) element.remove();
    }

    generateAgentResponse(message) {
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('summarize') || lowerMessage.includes('summary')) {
            return this.generatePatientSummary();
        } else if (lowerMessage.includes('priority') || lowerMessage.includes('urgent')) {
            return this.generatePriorityActions();
        } else if (lowerMessage.includes('report')) {
            return this.generateComprehensiveReport();
        } else if (lowerMessage.includes('test') || lowerMessage.includes('recommend')) {
            return this.generateTestRecommendations();
        } else if (lowerMessage.includes('risk') || lowerMessage.includes('assessment')) {
            return this.generateRiskAssessment();
        } else {
            return this.generateGeneralResponse(message);
        }
    }

    generatePatientSummary() {
        const hasData = Object.keys(this.sessionData).length > 0;
        
        if (!hasData) {
            return "I notice no modules have been used yet for this patient. To provide a comprehensive summary, please run some diagnostic modules first. You can start with the AI Diagnostic Assistant for symptom analysis or upload lab results for review.";
        }

        let summary = "**Patient Summary for John Doe (Age 45, Male)**\n\n";
        
        if (this.sessionData.diagnostic) {
            summary += "**🔍 Diagnostic Findings:**\n";
            summary += `- Primary concern: ${this.sessionData.diagnostic.conditions[0].condition} (${(this.sessionData.diagnostic.conditions[0].confidence * 100).toFixed(0)}% confidence)\n`;
            summary += `- Urgency level: ${this.sessionData.diagnostic.urgency}\n\n`;
        }
        
        if (this.sessionData.lab) {
            summary += "**📊 Laboratory Results:**\n";
            summary += `- ${this.sessionData.lab.summary}\n`;
            summary += `- ${this.sessionData.lab.abnormalValues.length} abnormal values detected\n\n`;
        }
        
        if (this.sessionData.scan) {
            summary += "**🏥 Imaging Results:**\n";
            summary += `- ${this.sessionData.scan.impression}\n\n`;
        }
        
        if (this.sessionData.genomics) {
            const highRiskConditions = this.sessionData.genomics.riskScores.filter(r => r.risk === 'High');
            summary += "**🧬 Genetic Risk Factors:**\n";
            summary += `- ${highRiskConditions.length} high-risk conditions identified\n\n`;
        }

        summary += "**📋 Overall Assessment:**\nMultiple clinical indicators suggest need for immediate cardiovascular evaluation and comprehensive workup.";
        
        return summary;
    }

    generatePriorityActions() {
        return `**🚨 Priority Actions for Current Patient:**

**IMMEDIATE (Within 1 hour):**
1. **ECG and Cardiac Monitoring** - Given chest pain symptoms
2. **Troponin Levels** - Rule out myocardial injury
3. **IV Access** - Prepare for potential interventions
4. **Aspirin 325mg** - Unless contraindicated

**URGENT (Within 2-4 hours):**
1. **Cardiology Consultation** - Expert evaluation needed
2. **Chest X-ray** - Evaluate cardiac silhouette and lungs
3. **Basic Metabolic Panel** - Assess electrolytes and renal function
4. **PT/INR if on anticoagulants**

**SHORT-TERM (Within 24 hours):**
1. **Echocardiogram** - Assess cardiac function
2. **Lipid Panel** - Cardiovascular risk stratification
3. **HbA1c** - Diabetes screening
4. **Discharge planning** - If stable after workup

**Risk Level: HIGH** - Patient requires continuous monitoring and may need urgent intervention.`;
    }

    generateComprehensiveReport() {
        return `**📋 Comprehensive Medical Report**

**Patient:** John Doe, 45-year-old Male (MRN: 12345)
**Date:** ${new Date().toLocaleDateString()}
**Generated by:** AIME AI Medical Assistant

**CHIEF COMPLAINT:**
Chest pain, shortness of breath, and fatigue

**CLINICAL SUMMARY:**
Multi-modal AI analysis reveals concerning findings requiring immediate medical attention. Patient presents with symptoms highly suggestive of acute coronary syndrome.

**KEY FINDINGS:**
• **Diagnostic AI:** 78% probability of ACS
• **Risk Factors:** Multiple cardiovascular risk indicators
• **Recommended Actions:** Emergency cardiac evaluation

**DISPOSITION:**
HIGH PRIORITY - Immediate medical attention required

**FOLLOW-UP:**
1. Cardiology consultation within 2 hours
2. Serial cardiac enzymes
3. Continuous monitoring
4. Repeat assessment after initial workup

This report combines insights from multiple AI modules to provide comprehensive clinical decision support.`;
    }

    generateTestRecommendations() {
        return `**🧪 Additional Test Recommendations:**

**IMMEDIATE LABS:**
• **Comprehensive Metabolic Panel** - Electrolytes, renal function
• **Lipase** - Rule out pancreatitis
• **D-Dimer** - If PE suspected
• **Arterial Blood Gas** - If hypoxemic

**IMAGING:**
• **CT Pulmonary Angiogram** - If high PE suspicion
• **Coronary CTA** - If stable for outpatient workup
• **Stress Test** - After acute phase if indicated

**SPECIALIZED TESTS:**
• **BNP/NT-proBNP** - Heart failure assessment
• **Thyroid Function** - Rule out hyperthyroidism
• **Inflammatory Markers** (ESR, CRP) - Systemic inflammation

**MONITORING:**
• **Continuous Telemetry** - Cardiac rhythm monitoring
• **Serial Vital Signs** - Q15min initially
• **Pulse Oximetry** - Continuous O2 monitoring

**Priority:** Focus on cardiac workup first, then expand based on initial results.`;
    }

    generateRiskAssessment() {
        return `**⚠️ Risk Stratification Analysis:**

**CARDIOVASCULAR RISK: HIGH**
• Age 45, Male gender
• Chest pain symptoms
• Family history considerations
• Multiple risk indicators present

**IMMEDIATE RISKS:**
• **Myocardial Infarction:** High probability (78%)
• **Arrhythmia:** Moderate risk
• **Sudden Cardiac Death:** Low but present

**RISK FACTORS:**
✓ Symptomatic chest pain
✓ Associated dyspnea
✓ Male gender, middle-aged
? Smoking history (unknown)
? Diabetes (screening needed)
? Hypertension (elevated BP noted)

**PROTECTIVE FACTORS:**
• Age <65 years
• No known prior cardiac events
• Stable vital signs currently

**RECOMMENDATION:**
This patient requires **IMMEDIATE RISK STRATIFICATION** in emergency department setting with cardiac workup protocol. Do not discharge without ruling out ACS.

**Risk Score:** 8/10 (High Risk)`;
    }

    generateGeneralResponse(message) {
        const responses = [
            "I'm analyzing your query in the context of the current patient data. Could you be more specific about what aspect you'd like me to focus on?",
            "Based on the available clinical data, I can provide more targeted insights if you specify whether you're interested in diagnostic, therapeutic, or prognostic information.",
            "I'm here to help with clinical decision support. You can ask me to summarize findings, prioritize actions, recommend tests, or generate reports.",
            "To provide the most helpful response, could you clarify if you're looking for immediate clinical actions or longer-term management strategies?"
        ];
        
        return responses[Math.floor(Math.random() * responses.length)];
    }

    // Placeholder functions for other modules
    handleScanUpload(event) {
        const files = event.target.files;
        if (files.length > 0) {
            const uploadArea = document.getElementById('scan-upload-area');
            if (uploadArea) {
                uploadArea.innerHTML = `
                    <div class="upload-content">
                        <span class="upload-icon">✅</span>
                        <h3>Files Uploaded</h3>
                        <p>${files.length} file(s) selected</p>
                        <p class="upload-note">Ready for analysis</p>
                    </div>
                `;
            }
        }
    }

    async analyzeScan() {
        const fileInput = document.getElementById('scan-file');
        const scanType = document.getElementById('scan-type');
        
        if (!fileInput || !fileInput.files.length) {
            alert('Please upload scan files first.');
            return;
        }
        
        if (!scanType || !scanType.value) {
            alert('Please select a scan type.');
            return;
        }

        this.showResults('scan');
        this.showLoading('scan-loading');
        await this.delay(3000);
        this.hideLoading('scan-loading');
        
        const output = document.getElementById('scan-output');
        if (output) {
            output.innerHTML = `
                <div class="results-header">
                    <h3 class="results-title">Scan Analysis Complete</h3>
                    <span class="confidence-score">AI Confidence: 84%</span>
                </div>
                <div class="results-card">
                    <h4>🔍 Analysis Results</h4>
                    <p>Mock scan analysis results would appear here. This demonstrates the interface functionality.</p>
                </div>
            `;
            output.classList.remove('hidden');
        }
    }

    handleGenomicsUpload(event) { /* Placeholder */ }
    async analyzeGenomics() { 
        this.showResults('genomics');
        this.showLoading('genomics-loading');
        await this.delay(3000);
        this.hideLoading('genomics-loading');
        
        const output = document.getElementById('genomics-output');
        if (output) {
            output.innerHTML = `
                <div class="results-header">
                    <h3 class="results-title">Genomic Analysis Complete</h3>
                    <span class="confidence-score">Analysis Quality: 89%</span>
                </div>
                <div class="results-card">
                    <h4>🧬 Analysis Results</h4>
                    <p>Mock genomic analysis results would appear here.</p>
                </div>
            `;
            output.classList.remove('hidden');
        }
    }
    
    handleLabUpload(event) { /* Placeholder */ }
    async analyzeLab() { 
        this.showResults('lab');
        this.showLoading('lab-loading');
        await this.delay(3000);
        this.hideLoading('lab-loading');
        
        const output = document.getElementById('lab-output');
        if (output) {
            output.innerHTML = `
                <div class="results-header">
                    <h3 class="results-title">Lab Analysis Complete</h3>
                    <span class="confidence-score">Parsing Accuracy: 94%</span>
                </div>
                <div class="results-card">
                    <h4>📊 Analysis Results</h4>
                    <p>Mock lab analysis results would appear here.</p>
                </div>
            `;
            output.classList.remove('hidden');
        }
    }
    
    async startWebcam() { /* Placeholder */ }
    stopWebcam() { /* Placeholder */ }
    handleMotionUpload(event) { /* Placeholder */ }
    async analyzeMotion() { 
        this.showResults('motion');
        this.showLoading('motion-loading');
        await this.delay(3000);
        this.hideLoading('motion-loading');
        
        const output = document.getElementById('motion-output');
        if (output) {
            output.innerHTML = `
                <div class="results-header">
                    <h3 class="results-title">Motion Analysis Complete</h3>
                    <span class="confidence-score">Analysis Confidence: 81%</span>
                </div>
                <div class="results-card">
                    <h4>🚶 Analysis Results</h4>
                    <p>Mock motion analysis results would appear here.</p>
                </div>
            `;
            output.classList.remove('hidden');
        }
    }

    // Utility Functions
    showResults(moduleId) {
        const results = document.getElementById(`${moduleId}-results`);
        if (results) results.classList.remove('hidden');
    }

    showLoading(loadingId) {
        const loading = document.getElementById(loadingId);
        if (loading) loading.classList.remove('hidden');
    }

    hideLoading(loadingId) {
        const loading = document.getElementById(loadingId);
        if (loading) loading.classList.add('hidden');
    }

    async delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    showDisclaimerModal() {
        const modal = document.getElementById('disclaimer-modal');
        if (modal) {
            modal.style.display = 'flex';
            modal.classList.remove('hidden');
            console.log('Disclaimer modal shown');
        }
    }

    hideDisclaimerModal() {
        const modal = document.getElementById('disclaimer-modal');
        if (modal) {
            modal.style.display = 'none';
            modal.classList.add('hidden');
            console.log('Disclaimer modal hidden');
        }
    }

    saveSessionData() {
        // Placeholder for session data saving
        console.log('Session data saved:', this.sessionData);
    }

    loadSessionData() {
        // Placeholder for session data loading
        console.log('Session data loaded');
    }

    exportReport() {
        const report = this.generateFullReport();
        this.downloadReport('aime-medical-report.txt', report);
    }

    generateFullReport() {
        const timestamp = new Date().toLocaleString();
        let report = `AIME MEDICAL REPORT\nGenerated: ${timestamp}\nPatient: John Doe (MRN: 12345)\n\n`;
        
        Object.keys(this.sessionData).forEach(module => {
            report += `=== ${module.toUpperCase()} MODULE ===\n`;
            report += JSON.stringify(this.sessionData[module], null, 2);
            report += '\n\n';
        });
        
        return report;
    }

    downloadReport(filename, content) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    newPatient() {
        if (confirm('Start a new patient session? This will clear all current data.')) {
            this.sessionData = {};
            this.saveSessionData();
            
            // Reset all result sections
            document.querySelectorAll('.results-section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Reset all inputs
            document.querySelectorAll('input, textarea, select').forEach(input => {
                if (input.type !== 'file') {
                    input.value = '';
                }
            });
            
            // Switch to dashboard
            this.switchModule('dashboard');
            
            alert('New patient session started.');
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AIMEApp();
});